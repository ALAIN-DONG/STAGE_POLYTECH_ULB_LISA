import pyb
import os
from time import sleep
import uos
import uio
import machine

from filters import median_filter,freq_filter,mean_filter,mean_std_filter
import lighting
import utime
from pyb import Pin
import handing_pin
import handing_file

from pyboard_vl53l0x import VL53L0X
#from new_vl53lox import VL53L0X
import handing_button
import handing_time_transition



XSHUT_PIN_TOF_0 = "X6"
XSHUT_PIN_TOF_1 = "X7"
XSHUT_PIN_TOF_2 = "X8"

ADDR_TOF_0 = 0x3C
ADDR_TOF_1 = 0x3A
ADDR_TOF_2 = 0x30



TIMEOUT_CAPTURE = 0  # constant for configure the interval of sampling
TIMEOUT_BUTTON = 500  # constant for distinguish the long press and short press
FILL_NAME = "DATA_CUPTURED"  # the csv file name

lighting.Light_Script_Ready()
# ##*********** The script is ready now, start your show *************##

# Step I : configure the different sensors so that they will have different address
# 1, configure the Xshut pins for sensors
pin_for_TOF_0 = pyb.Pin(XSHUT_PIN_TOF_0, pyb.Pin.OUT)
pin_for_TOF_1 = pyb.Pin(XSHUT_PIN_TOF_1, pyb.Pin.OUT)
pin_for_TOF_2 = pyb.Pin(XSHUT_PIN_TOF_2, pyb.Pin.OUT)

# 2, shutdown all pins
handing_pin.Pin_TurnOff_C(pin_for_TOF_0)
handing_pin.Pin_TurnOff_C(pin_for_TOF_1)
handing_pin.Pin_TurnOff_C(pin_for_TOF_2)

# 3, create a new i2c object
i2c = machine.I2C(sda='X10', scl='X9', freq=400000)


handing_pin.Pin_TurnOn_C(pin_for_TOF_0)
pyb.delay(10)
Tof0 = VL53L0X(i2c)
Tof0.set_timeout(TIMEOUT_CAPTURE)
Tof0.set_address(ADDR_TOF_0)
Tof0.init()
#print("After change the address of TOF0: ", i2c.scan())


# 4, configure TOF1's address
handing_pin.Pin_TurnOn_C(pin_for_TOF_1)  # turn on the pin of Xshut for the sensor TOF1
pyb.delay(10)  # necessary delay for the response of the change of pin's level
Tof1 = VL53L0X(i2c)  # connect the i2c bus with the sensor and initialize
Tof1.set_timeout(TIMEOUT_CAPTURE)  # configure the interval of the sampling
Tof1.set_address(ADDR_TOF_1)  # configure the address of the sensor TOF1
Tof1.init()  # redo the initialization of the sensor after change its address and timeout
#print("After change the address of TOF1: ", i2c.scan())
#myPin1.value(False)

# 5, configure TOF2's address
handing_pin.Pin_TurnOn_C(pin_for_TOF_2)
pyb.delay(10)
Tof2 = VL53L0X(i2c)
Tof2.set_timeout(TIMEOUT_CAPTURE)
Tof2.set_address(ADDR_TOF_2)
Tof2.init()
#print("After change the address of TOF2: ", i2c.scan())




# fin configuration of the address of the sensors

# Step II : write the datas into the file CSV while capturing
# 1, create a folder
handing_file.new_folder('data_csv')

# 2, create the file CSV
# content = "time,NB.TOF2,mmTOF2,NB.TOF3,mmTOF3\n"  # the columns head of the file csv
path = 'data_csv/' + FILL_NAME + '.csv'
handing_file.create_new_document(path)

lighting.Light_Script_Ready()  # it's ready to store datas into files
running = True

# 3, read from sensors and write into the file
start_time = utime.ticks_ms()
while True:

    sw = pyb.Switch()
    if sw.value():
        if handing_button.button_control(TIMEOUT_BUTTON) == "L":
            running = False
            lighting.Light_FinDeEcrire()
            break
        elif handing_button.button_control(TIMEOUT_BUTTON) == "S":
            running = not running
    if running:
        # handing_file.write_into_follow(path, handing_file.organiser_content("TOF0", handing_time_transition.calc_time(start_time, utime.ticks_ms()), Tof0.range))
        # handing_file.write_into_follow(path, handing_file.organiser_content("TOF1", handing_time_transition.calc_time(start_time, utime.ticks_ms()), Tof1.range))
        # handing_file.write_into_follow(path, handing_file.organiser_content("TOF2", handing_time_transition.calc_time(start_time, utime.ticks_ms()), Tof2.range))
        handing_file.organiser_content("TOF0", utime.ticks_ms(), Tof0.range)
        #handing_file.write_into_follow(path, handing_file.organiser_content("TOF0", utime.ticks_ms(), Tof0.range))
        handing_file.organiser_content("TOF1", utime.ticks_ms(), Tof1.range)
        #handing_file.write_into_follow(path, handing_file.organiser_content("TOF1", utime.ticks_ms(), Tof1.range))
        handing_file.organiser_content("TOF2", utime.ticks_ms(), Tof2.range)
        #handing_file.write_into_follow(path, handing_file.organiser_content("TOF2", utime.ticks_ms(), Tof2.range))

        lighting.Light_EnTrainDeEcrire()
    if running is not True:
        lighting.Light_Pause()


