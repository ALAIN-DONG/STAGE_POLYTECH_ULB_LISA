import pyb
form pyb import UART

uart1 = UART(1, baudrate=9600)

