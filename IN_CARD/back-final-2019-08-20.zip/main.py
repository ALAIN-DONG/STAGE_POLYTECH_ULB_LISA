import lighting
from ReadMultipleSensorsWithDiffAddr import capture


lighting.Light_Mian_Start()

# Optional parameter:
#   # SC_TOF0           : Turn on(True) or off(False) the sensor TOF0, defaut: False
    # SC_TOF1           : Turn on(True) or off(False) the sensor TOF1, defaut: False
    # SC_TOF2           : Turn on(True) or off(False) the sensor TOF2, defaut: False
    # TIMEOUT_CAPTURE   : constant for configure the timeout for whit the response of the sensor, defaut: (50)
    # TIMEOUT_BUTTON    : constant for distinguish the long press and short press, defaut: 500(ms)
    # DELAY             : constant for configure the interval of sampling, defaut: 48(ms)
capture(SC_TOF0 = True,SC_TOF0 = True,SC_TOF0 = True)


lighting.Light_EnRepos()
















# USELESS PART
# import ReadOnlyOneSensor
# import ReadMultipleSensors
# import pyb
# import os
# from time import sleep
# import uos
# import uio
# import machine
#
# from filters import median_filter,freq_filter,mean_filter,mean_std_filter
# import lighting
# import utime
# from pyb import Pin
# import handing_pin
# import handing_file
#
# from pyboard_vl53l0x import VL53L0X
# #from new_vl53lox import VL53L0X
# import handing_button
#
#
# XSHUT_PIN_TOF_1 = "X7"
# XSHUT_PIN_TOF_2 = "X8"
#
# ADDR_TOF_1 = 0x3A
# ADDR_TOF_2 = 0x30
#
# lighting.init_light()
# lighting.Light_Mian_Start()
#
#
#
# # ## ***************** BEGIN TO SHOW ********************** ##
#
# # i2c = machine.I2C(sda='X10', scl='X9', freq=400000)
# # i2c.scan()
#
# # shutdown pins of VL53L0X's "ACTIVE-LOW-ONLY ON TOLERANT TO 5V" will fly them
# # myPin1 = pyb.Pin(XSHUT_PIN_TOF_1, pyb.Pin.OUT)
# # myPin2 = pyb.Pin(XSHUT_PIN_TOF_2, pyb.Pin.OUT)
# # myPin1.value(False)
# # myPin2.value(False)
# #
# # myPin1.value(True)
# # pyb.delay(1000)
# # Tof1 = VL53L0X(i2c)
# # Tof1.set_address(ADDR_TOF_1)
# # myPin1.value(False)
# #
# # myPin2.value(True)
# # pyb.delay(1000)
# # Tof2 = VL53L0X(i2c)
# # Tof2.set_address(ADDR_TOF_2)
#
#
# """
# myPin1 = pyb.Pin(XSHUT_PIN_TOF_1, pyb.Pin.OUT)
# myPin2 = pyb.Pin(XSHUT_PIN_TOF_2, pyb.Pin.OUT)
# i2c = machine.I2C(sda='X10', scl='X9', freq=400000)
# print("Before: ", i2c.scan())
# myPin1.value(False)
# myPin2.value(False)
# myPin1.value(True)
# Tof1 = VL53L0X(i2c)
# Tof1.set_timeout(100)
# Tof1.set_address(0x30)
# pyb.delay(100)
# Tof1.init()
# print(Tof1.address)
# print(Tof1.timeout)
# print("After the first one: ", i2c.scan())
#
# while True:
#     print("the value of TOF1 is :", Tof1.range)
#     #print("the value of TOF2 is :", Tof2.range())
#     sw = pyb.Switch()
#     if sw.value():
#         if button_control() == "L":
#             break
# """
#
#
# # init
# myPin1 = pyb.Pin(XSHUT_PIN_TOF_1, pyb.Pin.OUT)
# myPin2 = pyb.Pin(XSHUT_PIN_TOF_2, pyb.Pin.OUT)
# i2c = machine.I2C(sda='X10', scl='X9', freq=400000)
# print("Before: ", i2c.scan())
# myPin1.value(False)
# myPin2.value(False)
#
# # first one
# myPin1.value(True)
#
# Tof1 = VL53L0X(i2c)
# Tof1.set_timeout(100)
# Tof1.set_address(ADDR_TOF_1)
# pyb.delay(100)
# Tof1.init()
# print("After the first one: ", i2c.scan())
# #myPin1.value(False)
#
# # second one
# myPin2.value(True)
# pyb.delay(100)
# Tof2 = VL53L0X(i2c)
# Tof2.set_timeout(100)
# Tof2.set_address(ADDR_TOF_2)
# pyb.delay(100)
# Tof2.init()
# print("After the first one: ", i2c.scan())
#
#
# myPin1.value(True)
# myPin2.value(True)
# print("After active the two pins: ", i2c.scan())
#
#
# #myPin1.value(True)
# #myPin2.value(False)
# #print("test active the first pins: ", i2c.scan())
#
# #myPin1.value(False)
# #myPin2.value(True)
# #print("test active the second pins: ", i2c.scan())
#
# #myPin1.value(True)
# #myPin2.value(True)
# print("After active the two pins END: ", i2c.scan())
#
#
# while True:
#     print("the value of TOF1 is :", Tof1.range)
#     print("the value of TOF2 is :", Tof2.range)
#     sw = pyb.Switch()
#     if sw.value():
#         if handing_button.button_control(500) == "L":
#             break
#
#
#
#
#
# # init_at_the_end
# myPin1.value(False)
# myPin2.value(False)
# i2c.scan()
#
# #
# # pyb.Pin(XSHUT_PIN_TOF_2, pyb.Pin.OUT)
# # pyb.delay(1000)
# # Tof2 = VL53L0X(i2c, address=ADDR_TOF_2)
#
#
#
#
#
# # # 0.configurate the active pin
# # handing_pin.Pin_TurnOn("X8")
# #
# # handing_pin.Pin_TurnOff("X7")
# #
# # # 1.Initialize I2C bus and sensor.
# # i2c = machine.I2C(sda='X10', scl='X9', freq=400000)  # sampling rate: 400 KHz => 2.5 us/time
# # i2c.scan()  # very important to add this sentence
# # # print('All i2c device connected :', i2c.scan())  # show all i2c device
#
#
# # 2. link the bus and the sensor
# # vl53 = VL53L0X(i2c=i2c, address=0x29)
# #
# #
# # vl53.start(30)
# # lighting.Light_Test_Ok(3)
# # while True:
# #     print("the value is :", vl53.read())
# #     sw = pyb.Switch()
# #     if sw.value():
# #         if button_control() == "L":
# #             vl53.stop()
# #             break
# #     lighting.toggle_light_once(0)
# #     utime.sleep_ms(50)
# #     lighting.Light_Test_Ok(1)
#
#
# # # II. METHOD
# # print("test2")
# # # BON with the old version
# # vl53 = VL53L0X(i2c, io_timeout_s=35)
# #
# # while True:
# #     print("the value is :", vl53.range)
# #     sw = pyb.Switch()
# #     if sw.value():
# #         if button_control() == "L":
# #             break
#
#
# ## III.
# #print("test11")
# #vl53 = VL53L0X(i2c=i2c, address=0x29, timeout_ms=40)
# #while True:
# #    print("the value is :", vl53.range())
# #    sw = pyb.Switch()
# #    if sw.value():
# #        if button_control() == "L":
# #            break
#
#
#
#
#
# # def button_control():
# #     ms_time_before = 0
# #     ms_time_after = 0
# #     sw_button = pyb.Switch()
# #     if sw_button.value():
# #         ms_time_before = utime.ticks_ms()
# #         while True:
# #             if (utime.ticks_ms() - ms_time_before) > 800:
# #                 lighting.turnon_light(2)
# #             if sw_button.value() is False:
# #                 ms_time_after = utime.ticks_ms()
# #                 break
# #     if (ms_time_after - ms_time_before) > 800:
# #         lighting.Light_Feedback_Button_Long()
# #         return "L"
# #     else:
# #         lighting.Light_Feedback_Button_Short()
# #         return "S"
# #
# #
# #
# #
# #
# #
# # lighting.init_light()
# #
# # lighting.Light_Mian_Start()
# # pyb.delay(1000)
# #
# # pinXshut = ['X11', 'X8', 'X9']
# #
# #
# # handing_pin.InitXshutPin(pinXshut)
# #
# # # press the button 'usr' to begin the catch
# # while True:
# #     sw = pyb.Switch()
# #     if sw.value():
# #         lighting.Light_Feedback_Button_Short()
# #         pyb.delay(1000)
# #         break
# #
# #
# # # # the part of the creation of the file CSV
# # #  Create a folder
# # handing_file.new_folder('data_csv')
# #
# # content = "time,NB.TOF2,mmTOF2,NB.TOF3,mmTOF3\n"
# # path = 'data_csv/' + 'all' + '.csv'
# # handing_file.create_new_document(path)
# #
# # print('*'*40)
# # running = True
# # # circulation for the two sensors
# # while True:
# #
# #     # ## control the action of this bloc
# #     # control the circulation via keyboard in terminal
# #     # data = usb.recv(1, timeout=0)
# #     # if data != b'':
# #     #     if data == b's':
# #     #         running = not running
# #     #     if data == b'\x1b':
# #     #         break
# #     # Or control the circulation via the button 'USR'
# #     # if sw.value():
# #     #     running = not running
# #     #     lighting.Light_Feedback_Button()
# #     #     break
# #     sw = pyb.Switch()
# #     if sw.value():
# #         if button_control() == "L":
# #             running = False
# #             break
# #         elif button_control() == "S":
# #             running = not running
# #
# #     # ##fin control
# #     if running:
# #         ReadMultipleSensors.Read_Multiple_Sensor("TOF1", "X8", True, path)
# #         handing_pin.Pin_TurnOff("X8")
# #
# #         ReadMultipleSensors.Read_Multiple_Sensor("TOF2", "X7", True, path)
# #
