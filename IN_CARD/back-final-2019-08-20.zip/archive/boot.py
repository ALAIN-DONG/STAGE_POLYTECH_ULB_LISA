import pyb
#pyb.usb_mode('VCP+HID')